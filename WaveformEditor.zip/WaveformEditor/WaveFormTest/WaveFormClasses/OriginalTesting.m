//
//  OriginalTesting.m
//  WaveFormTest
//
//  Created by Sean on 8/29/19.
//  Copyright © 2019 DroidZONE. All rights reserved.
//

#import <Foundation/Foundation.h>
/*
- (BOOL)editAudio:(NSURL *)url {
    
    NSString* inputFilePath = [url path];
    
    NSURL *fileToTrimURL = [NSURL fileURLWithPath:inputFilePath];
    AVAsset *avAsset = [AVAsset assetWithURL:fileToTrimURL];
    
    // get the first audio track
    NSArray *tracks = [avAsset tracksWithMediaType:AVMediaTypeAudio];
    if ([tracks count] == 0) return NO;
    
    AVAssetTrack *track = [tracks objectAtIndex:0];
    
    // create the export session
    
    AVAssetExportSession *exportSession = [AVAssetExportSession
                                           exportSessionWithAsset:avAsset
                                           presetName:AVAssetExportPresetAppleM4A];
    if (nil == exportSession) return NO;
    
    CMTime startTime = CMTimeMake(0, 1);
    CMTime stopTime = CMTimeMake(point1, 1);
    CMTimeRange exportTimeRange = CMTimeRangeFromTimeToTime(startTime, stopTime);
    
    
    // create fade in time range - 10 seconds starting at the beginning of trimmed asset
    CMTime startFadeInTime = startTime;
    CMTime endFadeInTime = CMTimeMake(point1 + 1, 1);
    CMTimeRange fadeInTimeRange = CMTimeRangeFromTimeToTime(startFadeInTime,
                                                            endFadeInTime);
    
    // setup audio mix
    AVMutableAudioMix *exportAudioMix = [AVMutableAudioMix audioMix];
    AVMutableAudioMixInputParameters *exportAudioMixInputParameters =
    [AVMutableAudioMixInputParameters audioMixInputParametersWithTrack:track];
    
    [exportAudioMixInputParameters setVolumeRampFromStartVolume:0.0 toEndVolume:1.0
                                                      timeRange:fadeInTimeRange];
    exportAudioMix.inputParameters = [NSArray
                                      arrayWithObject:exportAudioMixInputParameters];
    
    // configure export session  output with all our parameters
    exportSession.outputURL = [NSURL fileURLWithPath:filePath]; // output path
    exportSession.outputFileType = AVFileTypeAppleM4A; // output file type
    exportSession.timeRange = exportTimeRange; // trim time range
    //exportSession.audioMix = exportAudioMix; // fade in audio mix
    
    // perform the export
    [exportSession exportAsynchronouslyWithCompletionHandler:^{
        
        if (AVAssetExportSessionStatusCompleted == exportSession.status) {
            NSLog(@"Export Successful");
        } else if (AVAssetExportSessionStatusFailed == exportSession.status) {
            
            NSLog(@"Export Failed");
        } else {
            NSLog(@"Export Session Status: %ld", (long)exportSession.status);
        }
    }];
    
    return YES;}

- (BOOL)editAudio2:(NSURL *)url {
    
    NSString* inputFilePath = [url path];
    
    NSURL *fileToTrimURL = [NSURL fileURLWithPath:inputFilePath];
    AVAsset *avAsset = [AVAsset assetWithURL:fileToTrimURL];
    
    // get the first audio track
    NSArray *tracks = [avAsset tracksWithMediaType:AVMediaTypeAudio];
    if ([tracks count] == 0) return NO;
    
    AVAssetTrack *track = [tracks objectAtIndex:0];
    
    // create the export session
    
    AVAssetExportSession *exportSession = [AVAssetExportSession
                                           exportSessionWithAsset:avAsset
                                           presetName:AVAssetExportPresetAppleM4A];
    if (nil == exportSession) return NO;
    
    CMTime startTime = CMTimeMake(point2, 1);
    CMTime stopTime = CMTimeMake(CMTimeGetSeconds(exportSession.asset.duration), 1);
    CMTimeRange exportTimeRange = CMTimeRangeFromTimeToTime(startTime, stopTime);
    
    
    // create fade in time range - 10 seconds starting at the beginning of trimmed asset
    CMTime startFadeInTime = startTime;
    CMTime endFadeInTime = CMTimeMake(point2 + 1, 1);
    CMTimeRange fadeInTimeRange = CMTimeRangeFromTimeToTime(startFadeInTime,
                                                            endFadeInTime);
    
    // setup audio mix
    AVMutableAudioMix *exportAudioMix = [AVMutableAudioMix audioMix];
    AVMutableAudioMixInputParameters *exportAudioMixInputParameters =
    [AVMutableAudioMixInputParameters audioMixInputParametersWithTrack:track];
    
    [exportAudioMixInputParameters setVolumeRampFromStartVolume:0.0 toEndVolume:1.0
                                                      timeRange:fadeInTimeRange];
    exportAudioMix.inputParameters = [NSArray
                                      arrayWithObject:exportAudioMixInputParameters];
    
    // configure export session  output with all our parameters
    exportSession.outputURL = [NSURL fileURLWithPath:filePath2]; // output path
    exportSession.outputFileType = AVFileTypeAppleM4A; // output file type
    exportSession.timeRange = exportTimeRange; // trim time range
    //exportSession.audioMix = exportAudioMix; // fade in audio mix
    
    // perform the export
    [exportSession exportAsynchronouslyWithCompletionHandler:^{
        
        if (AVAssetExportSessionStatusCompleted == exportSession.status) {
            NSLog(@"Export Successful");
        } else if (AVAssetExportSessionStatusFailed == exportSession.status) {
            
            NSLog(@"Export Failed");
        } else {
            NSLog(@"Export Session Status: %ld", (long)exportSession.status);
        }
    }];
    
    return YES;}

- (void) combineFiles{
    NSLog(@"File Merging Initialized");
    
    NSString *sound1 = [[NSBundle mainBundle] pathForResource:filePath ofType:@"wav"];
    NSString *sound2 = [[NSBundle mainBundle] pathForResource:filePath2 ofType:@"wav"];
    
    NSURL *url = [NSURL URLWithString:sound1];
    NSURL *url2 = [NSURL URLWithString:sound2];
    
    AVAsset *audio1 = [AVURLAsset URLAssetWithURL:url options:nil];
    AVAsset *audio2 = [AVURLAsset URLAssetWithURL:url2 options:nil];
    
    AVMutableComposition* composition = [[AVMutableComposition alloc] init];
    
    AVMutableCompositionTrack *audioCombinedTrack = [composition addMutableTrackWithMediaType:AVMediaTypeAudio preferredTrackID:kCMPersistentTrackID_Invalid];
    [audioCombinedTrack insertTimeRange:CMTimeRangeMake(kCMTimeZero, [audio1 duration]) ofTrack:[audio1.tracks objectAtIndex:0] atTime:kCMTimeZero error:nil];
    [audioCombinedTrack insertTimeRange:CMTimeRangeMake(kCMTimeZero, [audio2 duration]) ofTrack:[audio2.tracks objectAtIndex:0] atTime:[audio1 duration] error:nil];
    NSLog(@"4");
    
    AVAssetExportSession *exportSession = [[AVAssetExportSession alloc] initWithAsset:composition presetName:AVAssetExportPresetPassthrough];
    
    // configure export session  output with all our parameters
    exportSession.outputURL = [NSURL fileURLWithPath:filePath3]; // output path
    exportSession.outputFileType = AVFileTypeAppleM4A; // output file type
    NSLog(@"5");
    [exportSession exportAsynchronouslyWithCompletionHandler:^{
        
        if (AVAssetExportSessionStatusCompleted == exportSession.status) {
            NSLog(@"Export Successful");
        } else if (AVAssetExportSessionStatusFailed == exportSession.status) {
            
            NSLog(@"Export Failed");
        } else {
            NSLog(@"Export Session Status: %ld", (long)exportSession.status);
        }
    }];
}
*/
